# Domains Tengine

This repository contains the reverse proxy mechanism for the mshops delegated domains traffic, which does a header host change and sends the original host on a custom header in order to not duplicate the nginx routing rules, and being able to previously break the TLS certificate.

### Deploying changes
In order to deploy a change on this infrastructure layer, we need to change the auto-scalling group's AMI, by changing the nginx.conf file, rebuilding the docker image, generating a new AMI on that particular instance, and setting it to the auto-scalling group.

### Initial setup
1. Installing docker
    ```sh
    $ sudo yum update -y
    $ sudo yum install -y docker

    $ sudo service docker start
    ```

    Optional (no more sudo before docker commands):
    ```sh
    $ sudo usermod -aG docker ec2-user
    ```
    You need to re-login ssh

2. Building docker image
    ```sh
    $ docker build -t tengine-poc .
    ```

3. Including docker run on instance start-up

    By adding the following line to /etc/rc.local:
    ```
    docker run -p 80:8080 tengine-poc
    ```

4. Building initial AMI

5. Assign AMI to a new auto-scalling group

### Accessing a EC2 instance
In order to access a EC2 instance, we need to first use batmanaws by simply using:
```
$ ssh batmanaws
```

And then ssh using the corresponding key pair instance with its private IP:
```
$ ssh -i "DomainsPOC.pem" ec2-user@10.64.233.160
```

### Testing
Once accessed an instance, we can use a curl to check if we get response from the Tengine:
```
$ curl localhost:80/ping
```
