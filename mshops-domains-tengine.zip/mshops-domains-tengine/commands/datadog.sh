#!/bin/bash
export DD_AGENT_MAJOR_VERSION=7
export DD_API_KEY=e5413844a124f3cf4fb41e72ee3a4fcf
export DD_SITE="datadoghq.com"
INSTALL_SOURCES=/opt/mshops-domains-tengine/datadog
DD_AGENT=/etc/datadog-agent

#########
# Installing Datadog
#########
bash -c "$(curl -L https://s3.amazonaws.com/dd-agent/scripts/install_script.sh)"

#########
# stop Datadog service
#########
service datadog-agent stop

#########
# Copy Datadog resources
#########

### Datadog config
cp "$INSTALL_SOURCES"/datadog.yaml "$DD_AGENT"/

### Datadog Agent configuration for nginx
rm -rf "$DD_AGENT"/conf.d/nginx.d/*
cp "$INSTALL_SOURCES"/nginx.yaml "$DD_AGENT"/conf.d/nginx.d/
mv "$DD_AGENT"/conf.d/nginx.d/nginx.yaml "$DD_AGENT"/conf.d/nginx.d/conf.yaml

#########
# start Datadog service
#########
service datadog-agent start